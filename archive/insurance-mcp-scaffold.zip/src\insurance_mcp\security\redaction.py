from typing import Any


SENSITIVE_KEYS = {"email", "phone", "address", "date_of_birth", "ssn"}


def redact(data: dict[str, Any], enabled: bool = True) -> dict[str, Any]:
    if not enabled:
        return data
    return {key: ("***REDACTED***" if key in SENSITIVE_KEYS and value else value) for key, value in data.items()}
