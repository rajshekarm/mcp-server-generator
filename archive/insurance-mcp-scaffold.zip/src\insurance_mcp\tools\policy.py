from fastmcp import FastMCP

from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.policy_service import PolicyService


def register_policy_tools(mcp: FastMCP, service: PolicyService) -> None:
    @mcp.tool
    def get_policy(policy_id: str, role: str = "agent") -> dict:
        """Retrieve policy coverage and status."""
        require_permission(role, "policy:read")
        return service.get(policy_id).model_dump(mode="json")
