from insurance_mcp.exceptions import NotFoundError


class DocumentStoreClient:
    def __init__(self) -> None:
        self.documents: dict[str, dict[str, str]] = {}

    def save(self, document_id: str, owner_id: str, name: str, content: str) -> dict[str, str]:
        document = {"id": document_id, "owner_id": owner_id, "name": name, "content": content}
        self.documents[document_id] = document
        return document

    def get(self, document_id: str) -> dict[str, str]:
        if document_id not in self.documents:
            raise NotFoundError(f"Document '{document_id}' not found")
        return self.documents[document_id]
