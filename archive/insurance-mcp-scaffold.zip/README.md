# Insurance MCP

A runnable FastMCP scaffold for customer, policy, quote, underwriting, claims,
billing, and document workflows. The included adapters use in-memory storage;
replace the classes in `integrations/` with API/database implementations.

## Run

```powershell
cd insurance/insurance-mcp
python -m pip install -e ".[dev]"
insurance-mcp
```

The default transport is `stdio`. Set `INSURANCE_MCP_TRANSPORT=http` and
optionally `INSURANCE_MCP_HOST` / `INSURANCE_MCP_PORT` for HTTP transport.

Every tool accepts a `role`. The starter roles are `agent`, `underwriter`,
`adjuster`, `billing`, and `admin`. Replace this demonstration input with
identity claims supplied by your MCP gateway before production use.

## Test

```powershell
pytest
```
