from fastmcp import FastMCP

from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.quote_service import QuoteService


def register_quote_tools(mcp: FastMCP, service: QuoteService) -> None:
    @mcp.tool
    def create_quote(customer_id: str, product: str, coverage_limit: float, risk_score: int,
                     role: str = "agent") -> dict:
        """Create a preliminary insurance quote."""
        require_permission(role, "quote:write")
        return service.create(customer_id, product, coverage_limit, risk_score).model_dump(mode="json")

    @mcp.tool
    def get_quote(quote_id: str, role: str = "underwriter") -> dict:
        """Retrieve a quote."""
        require_permission(role, "quote:read")
        return service.get(quote_id).model_dump(mode="json")
