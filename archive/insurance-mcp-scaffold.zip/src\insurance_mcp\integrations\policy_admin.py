from insurance_mcp.exceptions import NotFoundError
from insurance_mcp.models.policy import Policy
from insurance_mcp.models.quote import Quote


class PolicyAdminClient:
    def __init__(self) -> None:
        self.policies: dict[str, Policy] = {}
        self.quotes: dict[str, Quote] = {}

    def save_policy(self, policy: Policy) -> Policy:
        self.policies[policy.id] = policy
        return policy

    def get_policy(self, policy_id: str) -> Policy:
        if policy_id not in self.policies:
            raise NotFoundError(f"Policy '{policy_id}' not found")
        return self.policies[policy_id]

    def save_quote(self, quote: Quote) -> Quote:
        self.quotes[quote.id] = quote
        return quote

    def get_quote(self, quote_id: str) -> Quote:
        if quote_id not in self.quotes:
            raise NotFoundError(f"Quote '{quote_id}' not found")
        return self.quotes[quote_id]
