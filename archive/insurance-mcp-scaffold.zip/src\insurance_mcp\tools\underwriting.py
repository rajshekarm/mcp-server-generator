from fastmcp import FastMCP

from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.underwriting_service import UnderwritingService


def register_underwriting_tools(mcp: FastMCP, service: UnderwritingService) -> None:
    @mcp.tool
    def evaluate_quote(quote_id: str, role: str = "underwriter") -> dict:
        """Evaluate a quote using the scaffold's demonstration risk rules."""
        require_permission(role, "underwriting:write")
        return service.evaluate(quote_id).model_dump(mode="json")
