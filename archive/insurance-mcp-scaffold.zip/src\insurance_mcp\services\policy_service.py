from insurance_mcp.integrations.policy_admin import PolicyAdminClient
from insurance_mcp.models.policy import Policy


class PolicyService:
    def __init__(self, policy_admin: PolicyAdminClient) -> None:
        self.policy_admin = policy_admin

    def get(self, policy_id: str) -> Policy:
        return self.policy_admin.get_policy(policy_id)

    def create(self, policy: Policy) -> Policy:
        return self.policy_admin.save_policy(policy)
