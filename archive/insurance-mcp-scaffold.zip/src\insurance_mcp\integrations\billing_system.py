from insurance_mcp.exceptions import NotFoundError


class BillingSystemClient:
    def __init__(self) -> None:
        self.balances: dict[str, float] = {}

    def set_balance(self, policy_id: str, amount: float) -> float:
        self.balances[policy_id] = round(amount, 2)
        return self.balances[policy_id]

    def get_balance(self, policy_id: str) -> float:
        if policy_id not in self.balances:
            raise NotFoundError(f"Billing account for policy '{policy_id}' not found")
        return self.balances[policy_id]

    def record_payment(self, policy_id: str, amount: float) -> float:
        return self.set_balance(policy_id, max(0, self.get_balance(policy_id) - amount))
