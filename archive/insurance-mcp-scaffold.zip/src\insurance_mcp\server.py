from fastmcp import FastMCP

from insurance_mcp.config import settings
from insurance_mcp.integrations.billing_system import BillingSystemClient
from insurance_mcp.integrations.claims_system import ClaimsSystemClient
from insurance_mcp.integrations.crm import CRMClient
from insurance_mcp.integrations.document_store import DocumentStoreClient
from insurance_mcp.integrations.policy_admin import PolicyAdminClient
from insurance_mcp.services.billing_service import BillingService
from insurance_mcp.services.claims_service import ClaimsService
from insurance_mcp.services.customer_service import CustomerService
from insurance_mcp.services.policy_service import PolicyService
from insurance_mcp.services.quote_service import QuoteService
from insurance_mcp.services.underwriting_service import UnderwritingService
from insurance_mcp.tools.billing import register_billing_tools
from insurance_mcp.tools.claims import register_claim_tools
from insurance_mcp.tools.customer import register_customer_tools
from insurance_mcp.tools.documents import register_document_tools
from insurance_mcp.tools.policy import register_policy_tools
from insurance_mcp.tools.quote import register_quote_tools
from insurance_mcp.tools.underwriting import register_underwriting_tools


def create_server() -> FastMCP:
    """Build the server and wire replaceable integration adapters to tools."""
    mcp = FastMCP(name=settings.name)

    crm = CRMClient()
    policy_admin = PolicyAdminClient()
    claims_system = ClaimsSystemClient()
    billing_system = BillingSystemClient()
    document_store = DocumentStoreClient()

    register_customer_tools(mcp, CustomerService(crm))
    register_policy_tools(mcp, PolicyService(policy_admin))
    register_quote_tools(mcp, QuoteService(policy_admin))
    register_underwriting_tools(mcp, UnderwritingService(policy_admin))
    register_claim_tools(mcp, ClaimsService(claims_system))
    register_billing_tools(mcp, BillingService(billing_system))
    register_document_tools(mcp, document_store)
    return mcp


mcp = create_server()


def main() -> None:
    if settings.transport == "http":
        mcp.run(transport="http", host=settings.host, port=settings.port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
