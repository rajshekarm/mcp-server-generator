from datetime import date
from enum import StrEnum

from pydantic import BaseModel, Field


class ClaimStatus(StrEnum):
    OPEN = "open"
    REVIEW = "review"
    APPROVED = "approved"
    DENIED = "denied"
    PAID = "paid"


class Claim(BaseModel):
    id: str
    policy_id: str
    loss_date: date
    description: str = Field(min_length=3)
    amount: float = Field(gt=0)
    status: ClaimStatus = ClaimStatus.OPEN
