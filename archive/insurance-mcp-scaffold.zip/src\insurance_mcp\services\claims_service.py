from datetime import date
from uuid import uuid4

from insurance_mcp.integrations.claims_system import ClaimsSystemClient
from insurance_mcp.models.claim import Claim, ClaimStatus


class ClaimsService:
    def __init__(self, claims_system: ClaimsSystemClient) -> None:
        self.claims_system = claims_system

    def submit(self, policy_id: str, loss_date: date, description: str, amount: float) -> Claim:
        claim = Claim(id=f"clm_{uuid4().hex[:10]}", policy_id=policy_id, loss_date=loss_date,
                      description=description, amount=amount)
        return self.claims_system.save(claim)

    def get(self, claim_id: str) -> Claim:
        return self.claims_system.get(claim_id)

    def update_status(self, claim_id: str, status: ClaimStatus) -> Claim:
        claim = self.get(claim_id)
        claim.status = status
        return self.claims_system.save(claim)
