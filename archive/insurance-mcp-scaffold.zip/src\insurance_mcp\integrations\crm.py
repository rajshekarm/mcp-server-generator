from insurance_mcp.exceptions import NotFoundError
from insurance_mcp.models.customer import Customer


class CRMClient:
    def __init__(self) -> None:
        self.customers: dict[str, Customer] = {}

    def save(self, customer: Customer) -> Customer:
        self.customers[customer.id] = customer
        return customer

    def get(self, customer_id: str) -> Customer:
        try:
            return self.customers[customer_id]
        except KeyError as exc:
            raise NotFoundError(f"Customer '{customer_id}' not found") from exc
