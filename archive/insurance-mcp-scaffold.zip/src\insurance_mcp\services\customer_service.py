from uuid import uuid4

from insurance_mcp.integrations.crm import CRMClient
from insurance_mcp.models.customer import Customer


class CustomerService:
    def __init__(self, crm: CRMClient) -> None:
        self.crm = crm

    def create(self, **data: object) -> Customer:
        return self.crm.save(Customer(id=f"cus_{uuid4().hex[:10]}", **data))

    def get(self, customer_id: str) -> Customer:
        return self.crm.get(customer_id)
