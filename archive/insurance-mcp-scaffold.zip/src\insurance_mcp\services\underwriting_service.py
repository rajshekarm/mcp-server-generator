from insurance_mcp.integrations.policy_admin import PolicyAdminClient
from insurance_mcp.models.quote import Quote, QuoteStatus


class UnderwritingService:
    def __init__(self, policy_admin: PolicyAdminClient) -> None:
        self.policy_admin = policy_admin

    def evaluate(self, quote_id: str) -> Quote:
        quote = self.policy_admin.get_quote(quote_id)
        quote.status = QuoteStatus.APPROVED if quote.risk_score <= 65 else (
            QuoteStatus.REFERRED if quote.risk_score <= 85 else QuoteStatus.DECLINED
        )
        return self.policy_admin.save_quote(quote)
