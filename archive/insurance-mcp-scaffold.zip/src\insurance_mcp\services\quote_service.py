from uuid import uuid4

from insurance_mcp.integrations.policy_admin import PolicyAdminClient
from insurance_mcp.models.quote import Quote


class QuoteService:
    def __init__(self, policy_admin: PolicyAdminClient) -> None:
        self.policy_admin = policy_admin

    def create(self, customer_id: str, product: str, coverage_limit: float, risk_score: int) -> Quote:
        base_rate = {"auto": 0.025, "home": 0.008, "life": 0.012}.get(product.lower(), 0.02)
        premium = coverage_limit * base_rate * (0.75 + risk_score / 100)
        quote = Quote(id=f"quo_{uuid4().hex[:10]}", customer_id=customer_id, product=product,
                      risk_score=risk_score, coverage_limit=coverage_limit, annual_premium=round(premium, 2))
        return self.policy_admin.save_quote(quote)

    def get(self, quote_id: str) -> Quote:
        return self.policy_admin.get_quote(quote_id)
