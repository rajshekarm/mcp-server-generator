from uuid import uuid4

from fastmcp import FastMCP

from insurance_mcp.integrations.document_store import DocumentStoreClient
from insurance_mcp.security.authorization import require_permission


def register_document_tools(mcp: FastMCP, store: DocumentStoreClient) -> None:
    @mcp.tool
    def upload_document(owner_id: str, name: str, content: str, role: str = "adjuster") -> dict:
        """Store text document content; use signed object-storage URLs in production."""
        require_permission(role, "document:write")
        return store.save(f"doc_{uuid4().hex[:10]}", owner_id, name, content)

    @mcp.tool
    def get_document(document_id: str, role: str = "agent") -> dict:
        """Retrieve a stored document."""
        require_permission(role, "document:read")
        return store.get(document_id)
