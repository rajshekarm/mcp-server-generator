from datetime import date

from fastmcp import FastMCP

from insurance_mcp.models.claim import ClaimStatus
from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.claims_service import ClaimsService


def register_claim_tools(mcp: FastMCP, service: ClaimsService) -> None:
    @mcp.tool
    def submit_claim(policy_id: str, loss_date: date, description: str, amount: float,
                     role: str = "adjuster") -> dict:
        """Submit a first notice of loss."""
        require_permission(role, "claim:write")
        return service.submit(policy_id, loss_date, description, amount).model_dump(mode="json")

    @mcp.tool
    def get_claim(claim_id: str, role: str = "adjuster") -> dict:
        """Retrieve a claim."""
        require_permission(role, "claim:read")
        return service.get(claim_id).model_dump(mode="json")

    @mcp.tool
    def update_claim_status(claim_id: str, status: ClaimStatus, role: str = "adjuster") -> dict:
        """Advance or resolve a claim status."""
        require_permission(role, "claim:write")
        return service.update_status(claim_id, status).model_dump(mode="json")
