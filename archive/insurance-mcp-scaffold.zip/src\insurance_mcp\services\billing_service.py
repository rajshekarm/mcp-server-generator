from insurance_mcp.exceptions import ValidationError
from insurance_mcp.integrations.billing_system import BillingSystemClient


class BillingService:
    def __init__(self, billing_system: BillingSystemClient) -> None:
        self.billing_system = billing_system

    def get_balance(self, policy_id: str) -> float:
        return self.billing_system.get_balance(policy_id)

    def pay(self, policy_id: str, amount: float) -> float:
        if amount <= 0:
            raise ValidationError("Payment amount must be positive")
        return self.billing_system.record_payment(policy_id, amount)
