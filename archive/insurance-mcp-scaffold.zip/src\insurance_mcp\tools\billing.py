from fastmcp import FastMCP

from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.billing_service import BillingService


def register_billing_tools(mcp: FastMCP, service: BillingService) -> None:
    @mcp.tool
    def get_balance(policy_id: str, role: str = "billing") -> dict:
        """Get the outstanding policy balance."""
        require_permission(role, "billing:read")
        return {"policy_id": policy_id, "balance": service.get_balance(policy_id)}

    @mcp.tool
    def record_payment(policy_id: str, amount: float, role: str = "billing") -> dict:
        """Record a payment against a policy balance."""
        require_permission(role, "billing:write")
        return {"policy_id": policy_id, "balance": service.pay(policy_id, amount)}
