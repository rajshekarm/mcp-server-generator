"""Replaceable external-system adapters."""
