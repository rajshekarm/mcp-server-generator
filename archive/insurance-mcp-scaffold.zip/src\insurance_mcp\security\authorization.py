from insurance_mcp.exceptions import AuthorizationError


PERMISSIONS: dict[str, set[str]] = {
    "agent": {"customer:read", "customer:write", "policy:read", "quote:write", "document:read"},
    "underwriter": {"customer:read", "policy:read", "quote:read", "underwriting:write", "document:read"},
    "adjuster": {"customer:read", "policy:read", "claim:read", "claim:write", "document:read", "document:write"},
    "billing": {"customer:read", "policy:read", "billing:read", "billing:write"},
    "admin": {"*"},
}


def require_permission(role: str, permission: str) -> None:
    allowed = PERMISSIONS.get(role, set())
    if "*" not in allowed and permission not in allowed:
        raise AuthorizationError(f"Role '{role}' lacks permission '{permission}'")
