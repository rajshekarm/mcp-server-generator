from datetime import date

from fastmcp import FastMCP

from insurance_mcp.config import settings
from insurance_mcp.security.authorization import require_permission
from insurance_mcp.security.redaction import redact
from insurance_mcp.services.customer_service import CustomerService


def register_customer_tools(mcp: FastMCP, service: CustomerService) -> None:
    @mcp.tool
    def create_customer(full_name: str, email: str, date_of_birth: date, role: str = "agent",
                        phone: str | None = None, address: str | None = None) -> dict:
        """Create an insurance customer profile."""
        require_permission(role, "customer:write")
        return service.create(full_name=full_name, email=email, date_of_birth=date_of_birth,
                              phone=phone, address=address).model_dump(mode="json")

    @mcp.tool
    def get_customer(customer_id: str, role: str = "agent") -> dict:
        """Retrieve a customer, redacting PII when configured."""
        require_permission(role, "customer:read")
        return redact(service.get(customer_id).model_dump(mode="json"), settings.redact_pii)
