"""FastMCP tool registration modules."""
