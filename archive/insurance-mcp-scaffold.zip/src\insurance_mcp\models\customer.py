from datetime import date

from pydantic import BaseModel, EmailStr, Field


class Customer(BaseModel):
    id: str
    full_name: str = Field(min_length=1)
    email: EmailStr
    date_of_birth: date
    phone: str | None = None
    address: str | None = None
