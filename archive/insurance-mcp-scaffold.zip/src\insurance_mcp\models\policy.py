from datetime import date
from enum import StrEnum

from pydantic import BaseModel, Field


class PolicyStatus(StrEnum):
    ACTIVE = "active"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class Policy(BaseModel):
    id: str
    customer_id: str
    product: str
    status: PolicyStatus = PolicyStatus.ACTIVE
    effective_date: date
    expiration_date: date
    premium: float = Field(ge=0)
    coverage_limit: float = Field(gt=0)
