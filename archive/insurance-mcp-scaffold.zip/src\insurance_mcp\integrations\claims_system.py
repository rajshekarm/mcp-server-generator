from insurance_mcp.exceptions import NotFoundError
from insurance_mcp.models.claim import Claim


class ClaimsSystemClient:
    def __init__(self) -> None:
        self.claims: dict[str, Claim] = {}

    def save(self, claim: Claim) -> Claim:
        self.claims[claim.id] = claim
        return claim

    def get(self, claim_id: str) -> Claim:
        if claim_id not in self.claims:
            raise NotFoundError(f"Claim '{claim_id}' not found")
        return self.claims[claim_id]
