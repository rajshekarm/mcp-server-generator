from datetime import date

import pytest

from insurance_mcp.exceptions import AuthorizationError
from insurance_mcp.integrations.claims_system import ClaimsSystemClient
from insurance_mcp.integrations.policy_admin import PolicyAdminClient
from insurance_mcp.models.claim import ClaimStatus
from insurance_mcp.models.quote import QuoteStatus
from insurance_mcp.security.authorization import require_permission
from insurance_mcp.services.claims_service import ClaimsService
from insurance_mcp.services.quote_service import QuoteService
from insurance_mcp.services.underwriting_service import UnderwritingService


def test_quote_can_be_underwritten() -> None:
    admin = PolicyAdminClient()
    quote = QuoteService(admin).create("cus_1", "auto", 100_000, 50)

    evaluated = UnderwritingService(admin).evaluate(quote.id)

    assert evaluated.status == QuoteStatus.APPROVED
    assert evaluated.annual_premium > 0


def test_claim_lifecycle() -> None:
    service = ClaimsService(ClaimsSystemClient())
    claim = service.submit("pol_1", date(2026, 8, 1), "Windshield damage", 700)

    updated = service.update_status(claim.id, ClaimStatus.APPROVED)

    assert updated.status == ClaimStatus.APPROVED


def test_authorization_rejects_unknown_permission() -> None:
    with pytest.raises(AuthorizationError):
        require_permission("agent", "claim:write")
