"""Authorization and data-protection helpers."""
