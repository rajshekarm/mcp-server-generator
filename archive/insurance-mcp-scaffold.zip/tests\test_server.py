from insurance_mcp.server import create_server


def test_server_is_created() -> None:
    assert create_server().name == "Insurance MCP Server"
